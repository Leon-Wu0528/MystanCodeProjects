"""
File: boggle.py
Name:
----------------------------------------
TODO:
"""

import time

# This is the file name of the dictionary txt file
# we will be checking if a word exists by searching through it
FILE = 'dictionary.txt'


def main():
	"""
	TODO:
	"""
	start = time.time()
	####################
	# activate = True
	# alphabet_lst = []  # 用來裝入字母
	# origin_d = {}
	# s = ''
	# for i in range(4):
	# 	lst = []
	# 	print(i + 1, end=' ')
	# 	user_input_s = input('row of letters: ').lower()
	# 	for j in range(len(user_input_s)):
	# 		ch = user_input_s[j]
	# 		lst.append(ch)
	# 		if ch != ' ':
	# 			alphabet_lst.append(ch)
	# 			s += ch
	# 	if len(lst) == 7 and lst[1] and lst[3] and lst[5] is ' ':  # 確定輸入合乎標準
	# 		pass
	# 	else:
	# 		print('Illegal input')
	# 		activate = False
	# 		break
	# for i in range(len(alphabet_lst)):
	# 	origin_d[i] = alphabet_lst[i]
	# if activate is True:
	# 	find_anagrams(origin_d)
	origin_d = {0: 'f', 1: 'y', 2: 'c', 3: 'l', 4: 'i', 5: 'o', 6: 'm', 7: 'g', 8: 'o', 9: 'r', 10: 'i', 11: 'l'
		, 12: 'h', 13: 'j', 14: 'h', 15: 'u'}
	find_anagrams(origin_d)
	####################
	end = time.time()
	print('----------------------------------')
	print(f'The speed of your boggle algorithm: {end - start} seconds.')


def find_anagrams(origin_d):
	dictionary_list = read_dictionary()  # Read the dictionary
	ans_num = find_anagrams_helper(origin_d, origin_d, '', 0, dictionary_list)   # Call helper
	print('There are', ans_num, 'words in total')


def find_anagrams_helper(d, origin_d, current_s, ans_num, dictionary_list):
	if len(d) == 0:
		pass
	else:
		for key, value in d.items():
			new_d = {}
			if key == 0:
				del origin_d[key]
				for i in [1, 4, 5]:
					if i in origin_d:
						new_d[i] = origin_d[i]

			elif key == 1:
				del origin_d[key]
				for i in [0, 2, 4, 5, 6]:
					if i in origin_d:
						new_d[i] = origin_d[i]

			elif key == 2:
				del origin_d[key]
				for i in [1, 3, 5, 6, 7]:
					if i in origin_d:
						new_d[i] = origin_d[i]

			elif key == 3:
				del origin_d[key]
				for i in [2, 6, 7]:
					if i in origin_d:
						new_d[i] = origin_d[i]

			elif key == 4:
				del origin_d[key]
				for i in [0, 1, 5, 8, 9]:
					if i in origin_d:
						new_d[i] = origin_d[i]

			elif key == 5:
				del origin_d[key]
				for i in [0, 1, 2, 4, 6, 8, 9, 10]:
					if i in origin_d:
						new_d[i] = origin_d[i]

			elif key == 6:
				del origin_d[key]
				for i in [1, 2, 3, 5, 7, 9, 10, 11]:
					if i in origin_d:
						new_d[i] = origin_d[i]

			elif key == 7:
				del origin_d[key]
				for i in [2, 3, 6, 10, 11]:
					if i in origin_d:
						new_d[i] = origin_d[i]

			elif key == 8:
				del origin_d[key]
				for i in [4, 5, 9, 12, 13]:
					if i in origin_d:
						new_d[i] = origin_d[i]

			elif key == 9:
				del origin_d[key]
				for i in [4, 5, 6, 8, 10, 12, 13, 14]:
					if i in origin_d:
						new_d[i] = origin_d[i]

			elif key == 10:
				del origin_d[key]
				for i in [5, 6, 7, 9, 11, 13, 14, 15]:
					if i in origin_d:
						new_d[i] = origin_d[i]

			elif key == 11:
				del origin_d[key]
				for i in [6, 7, 10, 14, 15]:
					if i in origin_d:
						new_d[i] = origin_d[i]

			elif key == 12:
				del origin_d[key]
				for i in [8, 9, 13]:
					if i in origin_d:
						new_d[i] = origin_d[i]

			elif key == 13:
				del origin_d[key]
				for i in [8, 9, 10, 12, 14]:
					if i in origin_d:
						new_d[i] = origin_d[i]

			elif key == 14:
				del origin_d[key]
				for i in [9, 10, 11, 13, 15]:
					if i in origin_d:
						new_d[i] = origin_d[i]

			elif key == 15:
				del origin_d[key]
				for i in [10, 11, 14]:
					if i in origin_d:
						new_d[i] = origin_d[i]
			current_s += value
			if has_prefix(current_s, dictionary_list):
				find_anagrams_helper(new_d, origin_d, current_s, ans_num, dictionary_list)
			if current_s in dictionary_list:
				ans_num += 1
				print('Found' + '"' + current_s + '"')
			current_s = current_s[:-1]
	return ans_num


def read_dictionary():
	"""
	This function reads file "dictionary.txt" stored in FILE
	and appends words in each line into a Python list
	"""
	alphabet = []

	with open(FILE, 'r') as f:  # 1. Read the file.
		for word in f:  # 2. Read the contents.
			word = word.strip()  # 3. Remove the newline (\n).
			if len(word) >= 4:  # Ⅰ. word length should be the same
				alphabet.append(word)  # 4. Append the word to the list.

	return alphabet


def has_prefix(sub_s, dictionary_list):
	"""
	:param sub_s: (str) A substring that is constructed by neighboring letters on a 4x4 square grid
	:return: (bool) If there is any words with prefix stored in sub_s
	"""
	for word in dictionary_list:
		if word.startswith(sub_s):
			return True
	return False


if __name__ == '__main__':
	main()
